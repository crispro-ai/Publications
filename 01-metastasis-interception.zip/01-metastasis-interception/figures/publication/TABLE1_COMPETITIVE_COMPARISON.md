# Table 1: Comparison to Existing CRISPR Design Platforms

| Feature | Benchling | CRISPOR | CRISPick | **Interception** |
|---------|-----------|---------|----------|------------------|
| **Sequence-level scoring** | ✓ (GC content, off-target) | ✓ (CFD, MIT scores) | ✓ (Rule Set 2) | ✓ (Evo2 foundation model) |
| **Off-target prediction** | ✓ (BLAST-based) | ✓ (CFD score) | ✓ (CFD score) | ✓ (minimap2/BLAST exponential decay) |
| **Structural validation** | ✗ | ✗ | ✗ | ✓ **AlphaFold 3 Server** |
| **Foundation model scoring** | ✗ | ✗ | ✗ | ✓ **Evo2 (9.3T tokens)** |
| **Stage-specific targeting** | ✗ | ✗ | ✗ | ✓ **8-step metastatic cascade** |
| **Multi-modal integration** | ✗ | ✗ | ✗ | ✓ **4-signal Target-Lock (Functionality/Essentiality/Chromatin/Regulatory)** |
| **Structural pass rate** | Not reported | Not reported | Not reported | **100% (15/15 guides)** |
| **RNA-DNA threshold calibration** | ✗ | ✗ | ✗ | ✓ **pLDDT ≥50, iPTM ≥0.30** |
| **Reproducibility** | Limited (proprietary) | Open source | Open source | ✓ **One-command reproduction, fixed seeds** |
| **Provenance tracking** | Partial | Limited | Limited | ✓ **Full provenance (model versions, API calls, audit trails)** |

**Notes:**
- *Structural pass rate: Existing tools (Benchling, CRISPOR, CRISPick) do not report structural validation pass rates in published literature, as they lack integrated structural pre-screening. Failure rates from sequence-only design (where computationally "optimal" guides exhibit poor structural properties) have been reported in experimental studies, but exact percentages vary by experimental system (cell type, delivery method, guide design strategy). Our 100% pass rate (15/15) represents the first published computational structural validation success rate for CRISPR guide design.

**Key Differentiators:**
1. **Structural Pre-Validation**: Interception is the first platform to integrate AlphaFold 3 structural validation before synthesis, enabling pre-experimental identification of guides with poor structural properties.
2. **Foundation Model Integration**: Evo2 provides single-nucleotide resolution variant impact prediction without task-specific training, outperforming rule-based heuristics.
3. **Stage-Aware Design**: Mission-specific targeting across 8 metastatic cascade steps enables precision therapeutic design beyond generic gene editing.
